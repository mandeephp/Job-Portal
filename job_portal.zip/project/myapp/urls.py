from django.conf.urls import url

from . import views

urlpatterns=[

url(r'^$',views.index,name='index'),
url(r'^myapp/index1/',views.index1,name='index1'),
url(r'^myapp/signup/',views.register_user,name='signup'),
url(r'^myapp/register_success/$', views.register_success,name='register_success'),
url(r'^myapp/confirm/(?P<activation_key>\w+)/$', views.register_confirm,name='register_confirm'),
url(r'^myapp/login1/$', views.login1,name='login1'),
url(r'^myapp/cform/$', views.cform,name='cform'),
url(r'^myapp/dform/$', views.dform,name='dform'),
url(r'^myapp/check/$', views.check,name='check'),
url(r'^myapp/change/$', views.change,name='change'),
url(r'^myapp/notify/$', views.notify,name='notify'),
url(r'^myapp/apply/$', views.apply,name='apply'),
]
