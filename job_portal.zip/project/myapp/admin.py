from django.contrib import admin

# Register your models here.

from .models import *

admin.site.register(UserProfile)
admin.site.register(Company)
admin.site.register(New)
admin.site.register(Cg)
admin.site.register(UserData)

