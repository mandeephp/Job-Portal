from __future__ import unicode_literals

from django.contrib.auth.models import User
from django.db import models
import datetime                

# Create your models here.

class UserProfile(models.Model):
    user = models.OneToOneField(User)
    activation_key = models.CharField(max_length=40, blank=True)
    key_expires = models.DateTimeField(default=datetime.date.today())
    def __str__(self):
        return self.user.username


class UserData(models.Model):
    name = models.OneToOneField(User)
    stream = models.CharField(max_length=40, blank=True)
    technology = models.CharField(max_length=100,blank=True)
    cgp=models.IntegerField(max_length=100,blank=True)
    def __str__(self):
        return self.name.username

class Company(models.Model):
	name = models.CharField(max_length=100, blank=True)
	min_cgpa = models.IntegerField(max_length=100, blank=True)
	min_tenth = models.CharField(max_length=100, blank=True)
	min_twelve = models.CharField(max_length=100, blank=True)
	deadline = models.DateField()
	status = models.BooleanField(default=False)
	package=models.CharField(max_length=10,blank=True)
	link=models.CharField(max_length=100,blank=True)
        check=models.CharField(max_length=100,blank=True)
	def __unicode__(self):
		return self.name

class New(models.Model):
	data=models.TextField(max_length=400, blank=True)
	def __unicode__(self):
		return self.data

class Cg(models.Model):
	cgpa = models.CharField(max_length=5,blank=True)
	def __unicode__(self):
		return self.cgpa
